Source Link:https://osxlatitude.com/forums/topic/16926-optiplex-7040-micro-kp-with-monterey/


-Original EFI File Credit to (fmac)


Important:
!! Change your Bios Setting (Sata)  !!

(ahci mode)



Update Changes in config.plist:
~ SecureBootModel - Disabled




